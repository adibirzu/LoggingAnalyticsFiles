Content
Sources: [Windows Sysmon Events]
Labels: [#mitre]
Fields: [Account Name, RuleName, Technique name, Technique_id, User]

Reference
Parsers: [win_event_log]
Labels: [Account Logon, Account Management, Batch, CachedInteractive, DS Access, Detailed Tracking, Interactive, Logon/Logoff, Network, NetworkCleartext, NewCredentials, Object Access, Policy Change, Privilege Use, RemoteInteractive, Service, System, Unlock, access.read, access.write, access.write.delete, account.credential, account.group, add, alert.risk_indicator, application.execute, application.identity_management.resource, application.registry, audit, audit.modify, authentication.login, authentication.logout, authorization.acquire, authorization.check, authorization.create, authorization.delete, authorization.modify, create, create.backup, critical, delete, denied, error, failure, grant, host, host.directory, host.process, modify, modify.add, modify.delete, modify.disabled, modify.enabled, modify.lock, modify.password, modify.remove, modify.unlock, modify.update, network.connection, notice, policy.check, policy.create, policy.delete, policy.modify, policy.notify, quarantined, remove, restore.backup, revoke, system.admin.modify, system.background, system.background.abort, system.background.disabled, system.background.enabled, system.background.modified, system.background.restart, system.background.shutdown, system.background.startup, system.background.terminate, system.install.device, system.install.service, system.notify, system.shutdown, system.startup, warning]
Fields: [apphash, cat, data, destip, destport, eventcat, eventdesc, eventid, eventsubcat, mbody, mseccategory, msecconfig, msecoriginalaction, msecresult, msecrsrctype, msecseverity, msg, mtag, progdetail, srcip, usrauthmeth]
