Content
Parsers: [Suricata]
Fields: [SuricataSignature, SuricataSignatureID, flow.bytes_toserver, flow.nbytes_toclient, flow.pkts_toserver, http.length, http.url]

Reference
Fields: [actn, bkendstatuscode, compartmentid, conttype, datasrc, destip, destport, detectedtime, eventcat, eventtype, mbody, method, msecseverity, ocirsrcocid, prot, region, srcif, srcip, srcport, tenant, tranprot, usragclntname]
