Content
Parsers: [SuricataAlerts]
Fields: [SuricataSignature, SuricataSignatureID, VIEW_TIMESTAMP, flow.bytes_toserver, flow.nbytes_toclient, flow.pkts_toclient, flow.pkts_toserver]

Reference
Fields: [alertseverity, cat, compartmentid, destip, destport, direction, eventcat, eventtype, flowid, if, logid, mbody, ocirsrcocid, src, srcip, srcport, subj, tenant, time, tranprot, type]
